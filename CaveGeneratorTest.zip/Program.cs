﻿using System;

namespace CaveGeneratorTest1
{
    class Program
    {
        static void Main(string[] args)
        {
            int gridSize = 10;
            float randomFillPercent = 0.5f;

            CaveGenerator caveGenerator = new CaveGenerator(randomFillPercent,gridSize);

            caveGenerator.RandomizeMap();
            int[,] map = caveGenerator.GetMap();

            for (int x = 0; x < gridSize; x++)
            {
                for (int y = 0; y < gridSize; y++)
                {
                    Console.Write(map[x, y]);
                }
                Console.WriteLine();
            }
        }
    }
}
